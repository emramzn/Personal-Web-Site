<head>
	

	 	<script src="ckeditor/ckeditor.js" ></script>	


	<body > <textarea class="ckeditor" name="cked" > </textarea> </body>

</head>