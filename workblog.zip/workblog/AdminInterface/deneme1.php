

<head>
	


<textarea class="ckeditor" name="herhangi" ></textarea>


<script src="../ckeditor/ckeditor.js"  >
	
CKEDITOR.plugins.add('imageuplader', {
	init:function(editor){

		editor.config.filebrowserBrowseUrl='/ckeditor/plugins/imageuplader/imgbrowser.php';
	});


</script> 





</head>
<body>

</body>
