/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'el', {
	title: 'Μαθηματικά με τη γλώσσα TeX',
	button: 'Μαθηματικά',
	dialogInput: 'Γράψτε κώδικα TeX εδώ',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'Τεκμηρίωση TeX',
	loading: 'γίνεται φόρτωση…',
	pathName: 'μαθηματικά'
} );
