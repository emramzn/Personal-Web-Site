CKEDITOR.plugins.setLang( 'loremipsum', 'en', {
	title: 'Lorem Ipsum Generator',
	toolbar: 'Lorem Ipsum Generator',
	paragraph: 'Paraghraph',
	sentence: 'Sentence',
	paragraphs: 'Paraghraphs',
	sentences: 'Sentences'
} );